import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:kent_paulene_portfolio/main.dart';
import 'package:kent_paulene_portfolio/providers/app_state_provider.dart';
import 'package:kent_paulene_portfolio/services/network_service.dart';

void main() {
  testWidgets('App loads home dashboard smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(
      ChangeNotifierProvider(
        create: (_) => AppStateProvider(),
        child: const MasterPortfolioApp(),
      ),
    );

    // Verify home dashboard title is rendered
    expect(find.text('Master Portfolio Hub'), findsOneWidget);
  });

  test('NetworkService queues requests in simulated offline mode', () async {
    final networkService = NetworkService();
    networkService.toggleSimulatedOffline();
    expect(networkService.isSimulatedOffline, isTrue);
    expect(networkService.isOnline, isFalse);

    await networkService.initiateRequest(
      title: 'Offline Payload Test',
      payloadSize: '2.5 MB',
    );

    expect(networkService.queue.length, equals(1));
    expect(networkService.pendingCount, equals(1));
    expect(networkService.queue.first.status, equals(RequestStatus.queued));

    networkService.dispose();
  });
}
