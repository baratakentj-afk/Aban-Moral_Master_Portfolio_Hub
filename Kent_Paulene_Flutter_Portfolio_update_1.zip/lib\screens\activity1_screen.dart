import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state_provider.dart';
import '../widgets/custom_button.dart';

/// Activity 1: Interactive Counter & Math Hub
/// Demonstrates StatefulWidget for local, screen-specific state interactions.
class Activity1Screen extends StatefulWidget {
  const Activity1Screen({super.key});

  @override
  State<Activity1Screen> createState() => _Activity1ScreenState();
}

class _Activity1ScreenState extends State<Activity1Screen> {
  int _counter = 0;
  final List<String> _historyLog = [];

  void _incrementCounter(int amount) {
    setState(() {
      _counter += amount;
      _historyLog.insert(0, 'Added $amount ➔ Current: $_counter');
    });
  }

  void _decrementCounter(int amount) {
    setState(() {
      _counter -= amount;
      _historyLog.insert(0, 'Subtracted $amount ➔ Current: $_counter');
    });
  }

  void _multiplyCounter(int factor) {
    setState(() {
      final old = _counter;
      _counter *= factor;
      _historyLog.insert(0, 'Multiplied $old x $factor ➔ Current: $_counter');
    });
  }

  void _resetCounter() {
    setState(() {
      _counter = 0;
      _historyLog.insert(0, 'Reset counter to 0');
    });
  }

  void _clearHistory() {
    setState(() {
      _historyLog.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final appState = Provider.of<AppStateProvider>(context);
    final isCompleted = appState.isActivityCompleted('lab1');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Lab 1: Counter & Math Hub'),
        actions: [
          IconButton(
            icon: Icon(
              isCompleted ? Icons.check_circle : Icons.check_circle_outline,
              color: isCompleted ? Colors.green : null,
            ),
            tooltip: isCompleted ? 'Completed' : 'Mark as Complete',
            onPressed: () {
              appState.toggleActivityCompletion('lab1');
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Info Banner
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.deepPurple.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.deepPurple.withValues(alpha: 0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline, color: Colors.deepPurple),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'This screen uses StatefulWidget for local counter state and history logging.',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.textTheme.bodyMedium?.color,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Counter Display Card
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
                  child: Column(
                    children: [
                      Text(
                        'CURRENT VALUE',
                        style: theme.textTheme.labelMedium?.copyWith(
                          letterSpacing: 1.5,
                          fontWeight: FontWeight.bold,
                          color: Colors.deepPurple,
                        ),
                      ),
                      const SizedBox(height: 12),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 200),
                        transitionBuilder: (child, animation) => ScaleTransition(scale: animation, child: child),
                        child: Text(
                          '$_counter',
                          key: ValueKey<int>(_counter),
                          style: theme.textTheme.displayLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: _counter < 0
                                ? Colors.red
                                : (_counter > 0 ? Colors.deepPurple : theme.textTheme.displayLarge?.color),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Control Buttons (Responsive Row / CustomButton)
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 10,
                runSpacing: 10,
                children: [
                  CustomButton(
                    label: '+1',
                    icon: Icons.add,
                    color: Colors.deepPurple,
                    onPressed: () => _incrementCounter(1),
                  ),
                  CustomButton(
                    label: '+5',
                    icon: Icons.add_circle_outline,
                    color: Colors.deepPurple,
                    onPressed: () => _incrementCounter(5),
                  ),
                  CustomButton(
                    label: '-1',
                    icon: Icons.remove,
                    color: Colors.orange,
                    onPressed: () => _decrementCounter(1),
                  ),
                  CustomButton(
                    label: 'x2',
                    icon: Icons.close,
                    color: Colors.teal,
                    onPressed: () => _multiplyCounter(2),
                  ),
                  CustomButton(
                    label: 'Reset',
                    icon: Icons.refresh,
                    isOutlined: true,
                    color: Colors.redAccent,
                    onPressed: _resetCounter,
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // History Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Activity Log (${_historyLog.length})',
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  if (_historyLog.isNotEmpty)
                    TextButton.icon(
                      onPressed: _clearHistory,
                      icon: const Icon(Icons.delete_outline, size: 18),
                      label: const Text('Clear'),
                    ),
                ],
              ),

              const SizedBox(height: 8),

              // History Log List
              Expanded(
                child: _historyLog.isEmpty
                    ? Center(
                        child: Text(
                          'No math actions recorded yet.',
                          style: theme.textTheme.bodyMedium?.copyWith(color: Colors.grey),
                        ),
                      )
                    : ListView.separated(
                        physics: const BouncingScrollPhysics(),
                        itemCount: _historyLog.length,
                        separatorBuilder: (context, index) => const Divider(height: 1),
                        itemBuilder: (context, index) {
                          return ListTile(
                            dense: true,
                            leading: CircleAvatar(
                              radius: 12,
                              backgroundColor: Colors.deepPurple.withValues(alpha: 0.15),
                              child: Text(
                                '${_historyLog.length - index}',
                                style: const TextStyle(fontSize: 10, color: Colors.deepPurple),
                              ),
                            ),
                            title: Text(_historyLog[index]),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
