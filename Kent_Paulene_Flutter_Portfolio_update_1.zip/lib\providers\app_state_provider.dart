import 'package:flutter/material.dart';

/// Global AppStateProvider managing theme mode, user profile info,
/// and activity completion state across the entire application.
class AppStateProvider extends ChangeNotifier {
  // Global Theme Mode State
  ThemeMode _themeMode = ThemeMode.system;
  
  // User & Student Profile Information
  String _userName = "Kent & Paulene";
  String _userRole = "CS 416 - Mobile Computing 2";
  String _section = "BSCS 4th Year";
  
  // Track completion of activities (State Management Feature)
  final Set<String> _completedActivities = {};

  // Getters
  ThemeMode get themeMode => _themeMode;
  bool get isDarkMode => _themeMode == ThemeMode.dark;
  String get userName => _userName;
  String get userRole => _userRole;
  String get section => _section;
  Set<String> get completedActivities => _completedActivities;

  int get completedCount => _completedActivities.length;

  // Actions & Mutators
  void toggleTheme() {
    if (_themeMode == ThemeMode.dark) {
      _themeMode = ThemeMode.light;
    } else {
      _themeMode = ThemeMode.dark;
    }
    notifyListeners();
  }

  void setThemeMode(ThemeMode mode) {
    _themeMode = mode;
    notifyListeners();
  }

  void updateProfile({required String name, required String role, required String section}) {
    _userName = name.trim().isEmpty ? "Kent & Paulene" : name.trim();
    _userRole = role.trim().isEmpty ? "CS 416 - Mobile Computing 2" : role.trim();
    _section = section.trim().isEmpty ? "BSCS 4th Year" : section.trim();
    notifyListeners();
  }

  void toggleActivityCompletion(String activityId) {
    if (_completedActivities.contains(activityId)) {
      _completedActivities.remove(activityId);
    } else {
      _completedActivities.add(activityId);
    }
    notifyListeners();
  }

  bool isActivityCompleted(String activityId) {
    return _completedActivities.contains(activityId);
  }

  void resetToDefaults() {
    _themeMode = ThemeMode.system;
    _userName = "Kent & Paulene";
    _userRole = "CS 416 - Mobile Computing 2";
    _section = "BSCS 4th Year";
    _completedActivities.clear();
    notifyListeners();
  }
}
