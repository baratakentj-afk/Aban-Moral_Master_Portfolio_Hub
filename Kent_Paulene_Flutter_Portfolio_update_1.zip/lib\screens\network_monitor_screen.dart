import 'package:flutter/material.dart';
import '../services/network_service.dart';
import '../widgets/custom_button.dart';

/// Lab 4: Network Monitor & Request Queuing Screen
/// Demonstrates real-time stream subscription to network state changes,
/// error handling during connectivity drops, request queuing, and automatic recovery.
class NetworkMonitorScreen extends StatefulWidget {
  const NetworkMonitorScreen({super.key});

  @override
  State<NetworkMonitorScreen> createState() => _NetworkMonitorScreenState();
}

class _NetworkMonitorScreenState extends State<NetworkMonitorScreen> {
  late final NetworkService _networkService;

  @override
  void initState() {
    super.initState();
    _networkService = NetworkService();
    _networkService.addListener(_onServiceUpdate);
  }

  void _onServiceUpdate() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _networkService.removeListener(_onServiceUpdate);
    _networkService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final activeType = _networkService.activeInterface;
    final isOnline = _networkService.isOnline;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Lab 4: Network Monitor'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded),
            tooltip: 'Clear Queue & Logs',
            onPressed: () {
              _networkService.clearQueue();
              _networkService.clearLogs();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Queue and Activity Logs Cleared'),
                  duration: Duration(seconds: 1),
                ),
              );
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. Dynamic Real-Time Connection Interface Banner
              _buildNetworkStatusBanner(theme, activeType, isOnline),

              const SizedBox(height: 20),

              // 2. Control Actions & Request Generators
              _buildRequestControlCard(theme),

              const SizedBox(height: 24),

              // 3. Queue Summary & Request List
              _buildQueueSection(theme),

              const SizedBox(height: 24),

              // 4. Real-time Connection & Queue Activity Log
              _buildLogConsole(theme),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNetworkStatusBanner(ThemeData theme, NetworkInterfaceType activeType, bool isOnline) {
    Color bannerColor;
    IconData bannerIcon;
    String statusTitle;
    String statusSubtitle;

    switch (activeType) {
      case NetworkInterfaceType.wifi:
        bannerColor = Colors.teal;
        bannerIcon = Icons.wifi_rounded;
        statusTitle = 'Connected via Wi-Fi';
        statusSubtitle = 'High-speed stable connection • Real-time stream active';
        break;
      case NetworkInterfaceType.cellular:
        bannerColor = Colors.deepPurple;
        bannerIcon = Icons.signal_cellular_4_bar_rounded;
        statusTitle = 'Connected via Cellular';
        statusSubtitle = 'Mobile data active • Continuous request sync ready';
        break;
      case NetworkInterfaceType.offline:
        bannerColor = Colors.redAccent;
        bannerIcon = Icons.wifi_off_rounded;
        statusTitle = 'Offline / Connection Dropped';
        statusSubtitle = 'Requests will be queued safely and auto-retried on reconnect';
        break;
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20.0),
      decoration: BoxDecoration(
        color: bannerColor.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: bannerColor.withValues(alpha: 0.4), width: 1.5),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: bannerColor,
                  shape: BoxShape.circle,
                ),
                child: Icon(bannerIcon, color: Colors.white, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      statusTitle,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: bannerColor,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      statusSubtitle,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.textTheme.bodySmall?.color?.withValues(alpha: 0.8),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(height: 1),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Row(
                  children: [
                    Icon(
                      _networkService.isSimulatedOffline
                          ? Icons.bug_report_rounded
                          : Icons.stream_rounded,
                      size: 18,
                      color: bannerColor,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Simulate Connection Drop:',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                          color: theme.textTheme.bodyMedium?.color,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Switch.adaptive(
                value: _networkService.isSimulatedOffline,
                activeTrackColor: Colors.redAccent,
                onChanged: (val) {
                  _networkService.toggleSimulatedOffline();
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRequestControlCard(ThemeData theme) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: theme.dividerColor.withValues(alpha: 0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.cloud_upload_rounded, color: Colors.indigo),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Continuous Request Simulation',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Simulate long-running network calls. If connection drops mid-request, it catches the error and queues the payload for automatic recovery.',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                CustomButton(
                  label: 'Fetch Heavy Dataset (5MB)',
                  icon: Icons.download_rounded,
                  color: Colors.indigo,
                  onPressed: () {
                    _networkService.initiateRequest(
                      title: 'Fetch Heavy Analytics Dataset',
                      payloadSize: '5.2 MB',
                    );
                  },
                ),
                CustomButton(
                  label: 'Sync Profile Photos (12MB)',
                  icon: Icons.photo_library_rounded,
                  color: Colors.teal,
                  isOutlined: true,
                  onPressed: () {
                    _networkService.initiateRequest(
                      title: 'Sync High-Res Profile Photos',
                      payloadSize: '12.4 MB',
                    );
                  },
                ),
                CustomButton(
                  label: 'Enqueue Batch (3 Requests)',
                  icon: Icons.dynamic_feed_rounded,
                  color: Colors.deepOrange,
                  isOutlined: true,
                  onPressed: () {
                    _networkService.initiateRequest(
                      title: 'User Activity Logs Sync',
                      payloadSize: '1.1 MB',
                    );
                    _networkService.initiateRequest(
                      title: 'Database Backup Payload',
                      payloadSize: '8.7 MB',
                    );
                    _networkService.initiateRequest(
                      title: 'App Config Check',
                      payloadSize: '0.3 MB',
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQueueSection(ThemeData theme) {
    final queue = _networkService.queue;
    final pendingCount = _networkService.pendingCount;
    final completedCount = _networkService.completedCount;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Row(
                children: [
                  Flexible(
                    child: Text(
                      'Request Queue System',
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const SizedBox(width: 8),
                  if (pendingCount > 0)
                    Badge(
                      label: Text('$pendingCount Pending'),
                      backgroundColor: Colors.amber.shade800,
                    ),
                ],
              ),
            ),
            if (completedCount > 0) ...[
              const SizedBox(width: 8),
              Text(
                '$completedCount Completed',
                style: TextStyle(
                  color: Colors.green.shade700,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 12),
        if (queue.isEmpty)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(28.0),
            decoration: BoxDecoration(
              color: theme.cardColor,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: theme.dividerColor.withValues(alpha: 0.15)),
            ),
            child: Column(
              children: [
                Icon(Icons.inbox_rounded, size: 40, color: theme.disabledColor),
                const SizedBox(height: 8),
                Text(
                  'No Requests in Queue',
                  style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                Text(
                  'Click any request button above to add requests to the queue.',
                  style: theme.textTheme.bodySmall,
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          )
        else
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: queue.length,
            separatorBuilder: (context, index) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final req = queue[index];
              return _buildRequestItemTile(theme, req);
            },
          ),
      ],
    );
  }

  Widget _buildRequestItemTile(ThemeData theme, NetworkRequest req) {
    Color statusColor;
    String statusText;
    IconData statusIcon;

    switch (req.status) {
      case RequestStatus.queued:
        statusColor = Colors.amber.shade700;
        statusText = 'QUEUED';
        statusIcon = Icons.hourglass_top_rounded;
        break;
      case RequestStatus.processing:
        statusColor = Colors.blue;
        statusText = 'DOWNLOADING (${(req.progress * 100).toInt()}%)';
        statusIcon = Icons.sync_rounded;
        break;
      case RequestStatus.completed:
        statusColor = Colors.green;
        statusText = 'COMPLETED';
        statusIcon = Icons.check_circle_rounded;
        break;
      case RequestStatus.failed:
        statusColor = Colors.redAccent;
        statusText = 'FAILED (RETRYING)';
        statusIcon = Icons.error_outline_rounded;
        break;
    }

    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: req.status == RequestStatus.processing
              ? Colors.blue.withValues(alpha: 0.5)
              : theme.dividerColor.withValues(alpha: 0.15),
          width: req.status == RequestStatus.processing ? 1.5 : 1.0,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(statusIcon, color: statusColor, size: 22),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  req.title,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  statusText,
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  'ID: ${req.id} • Payload: ${req.payloadSize}',
                  style: theme.textTheme.bodySmall,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (req.retryCount > 0) ...[
                const SizedBox(width: 8),
                Text(
                  'Retries: ${req.retryCount}',
                  style: TextStyle(
                    color: Colors.deepOrange.shade700,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ],
          ),
          if (req.status == RequestStatus.processing) ...[
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: req.progress,
                backgroundColor: Colors.blue.withValues(alpha: 0.15),
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
                minHeight: 6,
              ),
            ),
          ],
          if (req.errorMessage != null) ...[
            const SizedBox(height: 8),
            Text(
              '⚠️ ${req.errorMessage}',
              style: TextStyle(
                color: Colors.red.shade700,
                fontSize: 12,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildLogConsole(ThemeData theme) {
    final logs = _networkService.logs;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Row(
                children: [
                  const Icon(Icons.terminal_rounded, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Stream Event Logs',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
            TextButton(
              onPressed: () => _networkService.clearLogs(),
              child: const Text('Clear Logs'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          height: 180,
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E1E), // Dark terminal background
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.grey.shade800),
          ),
          child: logs.isEmpty
              ? const Center(
                  child: Text(
                    'No network events recorded yet.',
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                )
              : ListView.builder(
                  itemCount: logs.length,
                  itemBuilder: (context, index) {
                    final log = logs[index];
                    Color logColor = Colors.greenAccent;
                    if (log.contains('ERROR') || log.contains('lost') || log.contains('OFFLINE')) {
                      logColor = Colors.redAccent;
                    } else if (log.contains('queued') || log.contains('transition')) {
                      logColor = Colors.amberAccent;
                    }

                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2.0),
                      child: Text(
                        log,
                        style: TextStyle(
                          color: logColor,
                          fontSize: 11,
                          fontFamily: 'monospace',
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
