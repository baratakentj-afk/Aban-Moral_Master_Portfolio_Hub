import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state_provider.dart';

/// Activity 3: Visual Style & Color Playground
/// Demonstrates local state controlling dynamic declarative UI widget properties.
class Activity3Screen extends StatefulWidget {
  const Activity3Screen({super.key});

  @override
  State<Activity3Screen> createState() => _Activity3ScreenState();
}

class _Activity3ScreenState extends State<Activity3Screen> {
  double _borderRadius = 20.0;
  double _elevation = 6.0;
  double _opacity = 1.0;
  Color _cardColor = Colors.orange;
  String _cardTitle = 'Declarative Card Preview';

  final List<Color> _presetColors = [
    Colors.orange,
    Colors.deepPurple,
    Colors.teal,
    Colors.pinkAccent,
    Colors.blueAccent,
    Colors.amber,
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final appState = Provider.of<AppStateProvider>(context);
    final isCompleted = appState.isActivityCompleted('lab3');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Lab 3: Color & UI Playground'),
        actions: [
          IconButton(
            icon: Icon(
              isCompleted ? Icons.check_circle : Icons.check_circle_outline,
              color: isCompleted ? Colors.green : null,
            ),
            tooltip: isCompleted ? 'Completed' : 'Mark as Complete',
            onPressed: () {
              appState.toggleActivityCompletion('lab3');
            },
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Info Box
              Text(
                'Interactive UI Generator',
                style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                'Adjust the sliders and parameters below to see declarative UI updates in real-time.',
                style: theme.textTheme.bodyMedium?.copyWith(color: theme.hintColor),
              ),

              const SizedBox(height: 24),

              // Live Preview Component
              Center(
                child: Opacity(
                  opacity: _opacity,
                  child: Material(
                    elevation: _elevation,
                    borderRadius: BorderRadius.circular(_borderRadius),
                    color: _cardColor,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(28.0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(_borderRadius),
                      ),
                      child: Column(
                        children: [
                          const Icon(
                            Icons.auto_awesome,
                            size: 40,
                            color: Colors.white,
                          ),
                          const SizedBox(height: 12),
                          Text(
                            _cardTitle.isEmpty ? 'Card Preview' : _cardTitle,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Radius: ${_borderRadius.toStringAsFixed(0)}px • Elevation: ${_elevation.toStringAsFixed(0)} • Opacity: ${(_opacity * 100).toStringAsFixed(0)}%',
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.9),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 32),

              // Controls Card
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Card Title Input
                      TextField(
                        onChanged: (val) => setState(() => _cardTitle = val),
                        decoration: InputDecoration(
                          labelText: 'Custom Card Title',
                          hintText: 'Enter text...',
                          prefixIcon: const Icon(Icons.edit_note_rounded),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Color Palette Presets
                      const Text(
                        'Accent Color:',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: _presetColors.map((color) {
                          final isSelected = _cardColor == color;
                          return GestureDetector(
                            onTap: () => setState(() => _cardColor = color),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              width: isSelected ? 44 : 36,
                              height: isSelected ? 44 : 36,
                              decoration: BoxDecoration(
                                color: color,
                                shape: BoxShape.circle,
                                border: isSelected ? Border.all(color: Colors.white, width: 3) : null,
                                boxShadow: isSelected
                                    ? [BoxShadow(color: color.withValues(alpha: 0.5), blurRadius: 8, spreadRadius: 2)]
                                    : null,
                              ),
                              child: isSelected ? const Icon(Icons.check, color: Colors.white, size: 20) : null,
                            ),
                          );
                        }).toList(),
                      ),

                      const SizedBox(height: 20),
                      const Divider(),

                      // Border Radius Slider
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Border Radius:'),
                          Text('${_borderRadius.toStringAsFixed(0)} px', style: const TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Slider(
                        value: _borderRadius,
                        min: 0,
                        max: 50,
                        activeColor: _cardColor,
                        onChanged: (val) => setState(() => _borderRadius = val),
                      ),

                      // Elevation Slider
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Elevation Shadow:'),
                          Text(_elevation.toStringAsFixed(0), style: const TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Slider(
                        value: _elevation,
                        min: 0,
                        max: 20,
                        activeColor: _cardColor,
                        onChanged: (val) => setState(() => _elevation = val),
                      ),

                      // Opacity Slider
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Card Opacity:'),
                          Text('${(_opacity * 100).toStringAsFixed(0)}%', style: const TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Slider(
                        value: _opacity,
                        min: 0.2,
                        max: 1.0,
                        activeColor: _cardColor,
                        onChanged: (val) => setState(() => _opacity = val),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
