import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state_provider.dart';

class TaskItem {
  final String id;
  String title;
  String category;
  bool isDone;

  TaskItem({
    required this.id,
    required this.title,
    required this.category,
    this.isDone = false,
  });
}

/// Activity 2: Task & Lab Notes Planner
/// Demonstrates StatefulWidget for dynamic list management, filtering, and local state.
class Activity2Screen extends StatefulWidget {
  const Activity2Screen({super.key});

  @override
  State<Activity2Screen> createState() => _Activity2ScreenState();
}

class _Activity2ScreenState extends State<Activity2Screen> {
  final List<TaskItem> _tasks = [
    TaskItem(id: '1', title: 'Complete Lab 1 Counter Activity', category: 'Laboratory', isDone: true),
    TaskItem(id: '2', title: 'Design Master Portfolio UI Layout', category: 'Project', isDone: true),
    TaskItem(id: '3', title: 'Implement Provider Global Theme Toggle', category: 'State Mgmt', isDone: false),
    TaskItem(id: '4', title: 'Prepare Documentation for CS 416', category: 'Submission', isDone: false),
  ];

  String _filterCategory = 'All';
  final TextEditingController _taskController = TextEditingController();
  String _selectedCategory = 'Laboratory';

  List<TaskItem> get _filteredTasks {
    if (_filterCategory == 'Pending') {
      return _tasks.where((t) => !t.isDone).toList();
    } else if (_filterCategory == 'Completed') {
      return _tasks.where((t) => t.isDone).toList();
    }
    return _tasks;
  }

  void _addTask() {
    final text = _taskController.text.trim();
    if (text.isEmpty) return;

    setState(() {
      _tasks.add(
        TaskItem(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          title: text,
          category: _selectedCategory,
        ),
      );
      _taskController.clear();
    });
    Navigator.pop(context);
  }

  void _toggleTask(String id) {
    setState(() {
      final task = _tasks.firstWhere((t) => t.id == id);
      task.isDone = !task.isDone;
    });
  }

  void _deleteTask(String id) {
    setState(() {
      _tasks.removeWhere((t) => t.id == id);
    });
  }

  void _showAddTaskModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            top: 20,
            left: 20,
            right: 20,
          ),
          child: StatefulBuilder(
            builder: (context, setModalState) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Add New Task / Note',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _taskController,
                    autofocus: true,
                    decoration: InputDecoration(
                      labelText: 'Task Description',
                      hintText: 'e.g. Build Provider state model...',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const Text('Category: '),
                      const SizedBox(width: 10),
                      DropdownButton<String>(
                        value: _selectedCategory,
                        items: ['Laboratory', 'Project', 'State Mgmt', 'Submission']
                            .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                            .toList(),
                        onChanged: (val) {
                          if (val != null) {
                            setModalState(() => _selectedCategory = val);
                          }
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _addTask,
                      icon: const Icon(Icons.add),
                      label: const Text('Add Task'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final appState = Provider.of<AppStateProvider>(context);
    final isCompleted = appState.isActivityCompleted('lab2');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Lab 2: Task & Notes Planner'),
        actions: [
          IconButton(
            icon: Icon(
              isCompleted ? Icons.check_circle : Icons.check_circle_outline,
              color: isCompleted ? Colors.green : null,
            ),
            tooltip: isCompleted ? 'Completed' : 'Mark as Complete',
            onPressed: () {
              appState.toggleActivityCompletion('lab2');
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddTaskModal,
        icon: const Icon(Icons.add),
        label: const Text('New Task'),
        backgroundColor: Colors.teal,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Filter Segmented Buttons
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: ['All', 'Pending', 'Completed'].map((filter) {
                    final isSelected = _filterCategory == filter;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: ChoiceChip(
                        label: Text(filter),
                        selected: isSelected,
                        selectedColor: Colors.teal.withValues(alpha: 0.2),
                        onSelected: (selected) {
                          if (selected) {
                            setState(() => _filterCategory = filter);
                          }
                        },
                      ),
                    );
                  }).toList(),
                ),
              ),

              const SizedBox(height: 16),

              // Task List View
              Expanded(
                child: _filteredTasks.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.assignment_outlined, size: 64, color: theme.disabledColor),
                            const SizedBox(height: 12),
                            Text('No tasks found in $_filterCategory.', style: TextStyle(color: theme.disabledColor)),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: _filteredTasks.length,
                        physics: const BouncingScrollPhysics(),
                        itemBuilder: (context, index) {
                          final task = _filteredTasks[index];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            child: ListTile(
                              leading: Checkbox(
                                value: task.isDone,
                                activeColor: Colors.teal,
                                onChanged: (_) => _toggleTask(task.id),
                              ),
                              title: Text(
                                task.title,
                                style: TextStyle(
                                  decoration: task.isDone ? TextDecoration.lineThrough : null,
                                  color: task.isDone ? theme.disabledColor : null,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              subtitle: Padding(
                                padding: const EdgeInsets.only(top: 4.0),
                                child: UnconstrainedBox(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: Colors.teal.withValues(alpha: 0.15),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Text(
                                      task.category,
                                      style: const TextStyle(fontSize: 10, color: Colors.teal, fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete_outline, color: Colors.redAccent, size: 20),
                                onPressed: () => _deleteTask(task.id),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
