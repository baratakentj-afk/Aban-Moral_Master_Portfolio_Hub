package com.example.kent_paulene_portfolio

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
