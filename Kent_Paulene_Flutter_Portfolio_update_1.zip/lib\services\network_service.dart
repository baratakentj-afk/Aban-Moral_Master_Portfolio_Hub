import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

/// Active network interface state
enum NetworkInterfaceType { wifi, cellular, offline }

/// Status of a simulated network request
enum RequestStatus { queued, processing, completed, failed }

/// Model representing a long-running or continuous network request
class NetworkRequest {
  final String id;
  final String title;
  final String payloadSize;
  RequestStatus status;
  double progress; // 0.0 to 1.0
  final DateTime timestamp;
  int retryCount;
  String? errorMessage;

  NetworkRequest({
    required this.id,
    required this.title,
    required this.payloadSize,
    this.status = RequestStatus.queued,
    this.progress = 0.0,
    required this.timestamp,
    this.retryCount = 0,
    this.errorMessage,
  });
}

/// Service managing real-time connectivity streams, simulated network drops,
/// request queuing, and automatic graceful recovery upon reconnection.
class NetworkService extends ChangeNotifier {
  final Connectivity _connectivity = Connectivity();
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;

  NetworkInterfaceType _realInterface = NetworkInterfaceType.offline;
  bool _isSimulatedOffline = false;
  
  final List<NetworkRequest> _queue = [];
  final List<String> _logs = [];
  bool _isProcessingQueue = false;

  NetworkService() {
    _initConnectivity();
    _connectivitySubscription = _connectivity.onConnectivityChanged.listen(_updateConnectionStatus);
  }

  // Getters
  NetworkInterfaceType get realInterface => _realInterface;
  bool get isSimulatedOffline => _isSimulatedOffline;

  /// Effective interface takes user manual simulation override into account
  NetworkInterfaceType get activeInterface {
    if (_isSimulatedOffline) return NetworkInterfaceType.offline;
    return _realInterface;
  }

  bool get isOnline => activeInterface != NetworkInterfaceType.offline;
  List<NetworkRequest> get queue => List.unmodifiable(_queue);
  List<String> get logs => List.unmodifiable(_logs);
  bool get isProcessingQueue => _isProcessingQueue;

  int get pendingCount => _queue.where((r) => r.status == RequestStatus.queued || r.status == RequestStatus.failed).length;
  int get completedCount => _queue.where((r) => r.status == RequestStatus.completed).length;

  Future<void> _initConnectivity() async {
    try {
      final results = await _connectivity.checkConnectivity();
      _updateConnectionStatus(results);
    } catch (e) {
      _realInterface = NetworkInterfaceType.offline;
      notifyListeners();
    }
  }

  void _updateConnectionStatus(List<ConnectivityResult> results) {
    final prevInterface = activeInterface;

    if (results.contains(ConnectivityResult.wifi)) {
      _realInterface = NetworkInterfaceType.wifi;
    } else if (results.contains(ConnectivityResult.mobile)) {
      _realInterface = NetworkInterfaceType.cellular;
    } else if (results.contains(ConnectivityResult.ethernet)) {
      _realInterface = NetworkInterfaceType.wifi;
    } else {
      _realInterface = NetworkInterfaceType.offline;
    }

    final newInterface = activeInterface;
    
    // Log state transitions
    if (prevInterface != newInterface) {
      _addLog('Network state transition: ${prevInterface.name.toUpperCase()} -> ${newInterface.name.toUpperCase()}');
      
      // Graceful Recovery Trigger: if transition to Online state, auto-resume queue!
      if (newInterface != NetworkInterfaceType.offline) {
        _addLog('Connection restored! Triggering automatic recovery of queued requests...');
        processQueue();
      } else {
        _addLog('Connection lost during handover/migration. Requests will be queued safely.');
      }
    }

    notifyListeners();
  }

  /// Toggle manual simulation mode for offline/online testing
  void toggleSimulatedOffline() {
    _isSimulatedOffline = !_isSimulatedOffline;
    _addLog(_isSimulatedOffline ? 'Simulated Offline Mode ACTIVATED' : 'Simulated Offline Mode DEACTIVATED');
    
    if (!_isSimulatedOffline && isOnline) {
      _addLog('Simulated network re-established. Resuming pending requests...');
      processQueue();
    }
    notifyListeners();
  }

  /// Simulates initiating a network request (e.g. fetching 5MB dataset)
  Future<void> initiateRequest({required String title, required String payloadSize}) async {
    final requestId = 'REQ-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
    final request = NetworkRequest(
      id: requestId,
      title: title,
      payloadSize: payloadSize,
      timestamp: DateTime.now(),
    );

    _queue.add(request);
    _addLog('Initiated request $requestId ($title)');
    notifyListeners();

    // Try processing immediately if online
    if (isOnline) {
      await processQueue();
    } else {
      _addLog('Request $requestId queued (Offline mode active)');
    }
  }

  /// Sequential processing of request queue with error handling and retry logic
  Future<void> processQueue() async {
    if (_isProcessingQueue) return;
    _isProcessingQueue = true;
    notifyListeners();

    while (isOnline) {
      // Find next request to process (queued or failed)
      final pendingIndex = _queue.indexWhere(
        (r) => r.status == RequestStatus.queued || r.status == RequestStatus.failed,
      );

      if (pendingIndex == -1) break; // All done!

      final req = _queue[pendingIndex];
      req.status = RequestStatus.processing;
      req.errorMessage = null;
      notifyListeners();

      _addLog('Processing ${req.id}: Downloading ${req.payloadSize} dataset...');

      // Simulate step-by-step progress over 1.5 seconds
      bool failedMidway = false;
      for (int step = 1; step <= 5; step++) {
        await Future.delayed(const Duration(milliseconds: 300));

        // Check if network dropped mid-transfer
        if (!isOnline) {
          failedMidway = true;
          req.status = RequestStatus.failed;
          req.retryCount++;
          req.errorMessage = 'Network connection dropped during transfer';
          _addLog('❌ ERROR on ${req.id}: Connection lost mid-transfer! Added to auto-retry queue.');
          notifyListeners();
          break;
        }

        req.progress = step / 5.0;
        notifyListeners();
      }

      if (!failedMidway) {
        req.status = RequestStatus.completed;
        req.progress = 1.0;
        _addLog('✅ SUCCESS ${req.id}: Completed dataset transfer (${req.payloadSize})');
        notifyListeners();
      }
    }

    _isProcessingQueue = false;
    notifyListeners();
  }

  void clearQueue() {
    _queue.clear();
    _addLog('Queue cleared by user');
    notifyListeners();
  }

  void clearLogs() {
    _logs.clear();
    notifyListeners();
  }

  void _addLog(String text) {
    final timestamp = DateTime.now().toString().split(' ')[1].substring(0, 8);
    _logs.insert(0, '[$timestamp] $text');
    if (_logs.length > 50) _logs.removeLast();
  }

  @override
  void dispose() {
    _connectivitySubscription?.cancel();
    super.dispose();
  }
}
