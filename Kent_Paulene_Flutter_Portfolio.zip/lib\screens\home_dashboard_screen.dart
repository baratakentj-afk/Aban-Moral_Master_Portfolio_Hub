import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state_provider.dart';
import '../widgets/activity_card.dart';
import '../widgets/stat_summary_card.dart';

/// Home Dashboard acting as the Master Menu for laboratory activities.
/// Uses Consumer provider listener to automatically react to global state updates.
class HomeDashboardScreen extends StatelessWidget {
  const HomeDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final appState = Provider.of<AppStateProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Master Portfolio Hub',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: false,
        actions: [
          IconButton(
            icon: Icon(
              appState.isDarkMode ? Icons.wb_sunny_rounded : Icons.nightlight_round,
              color: appState.isDarkMode ? Colors.amber : Colors.indigo,
            ),
            tooltip: appState.isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode',
            onPressed: () {
              appState.toggleTheme();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    appState.isDarkMode ? 'Dark Theme Activated' : 'Light Theme Activated',
                  ),
                  duration: const Duration(seconds: 1),
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings_rounded),
            tooltip: 'Settings',
            onPressed: () {
              Navigator.pushNamed(context, '/settings');
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final isWideScreen = constraints.maxWidth > 700;

            return SingleChildScrollView(
              padding: const EdgeInsets.all(20.0),
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Hero Header with Dynamic Global State User Profile
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24.0),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: appState.isDarkMode
                            ? [const Color(0xFF3F51B5), const Color(0xFF1A237E)]
                            : [const Color(0xFF673AB7), const Color(0xFF512DA8)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: (appState.isDarkMode ? Colors.indigo : Colors.deepPurple)
                              .withValues(alpha: 0.3),
                          blurRadius: 16,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 28,
                              backgroundColor: Colors.white.withValues(alpha: 0.2),
                              child: const Icon(
                                Icons.school_rounded,
                                color: Colors.white,
                                size: 32,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Welcome, ${appState.userName}',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    '${appState.userRole} • ${appState.section}',
                                    style: TextStyle(
                                      color: Colors.white.withValues(alpha: 0.85),
                                      fontSize: 13,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          'Laboratory Activities & State Compilation',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Select any activity card below to launch laboratory modules.',
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.75),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Quick Stats Row (Responsive Row/Column)
                  Row(
                    children: [
                      Expanded(
                        child: StatSummaryCard(
                          title: 'Activities',
                          value: '3 Modules',
                          subtitle: '${appState.completedCount} Completed',
                          icon: Icons.assignment_turned_in_rounded,
                          color: Colors.teal,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: StatSummaryCard(
                          title: 'Global State',
                          value: appState.isDarkMode ? 'Dark Mode' : 'Light Mode',
                          subtitle: 'Live Provider Sync',
                          icon: appState.isDarkMode ? Icons.dark_mode : Icons.light_mode,
                          color: Colors.orange,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 28),

                  // Section Title
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          'Laboratory Compilation',
                          style: theme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Chip(
                        avatar: const Icon(Icons.stars_rounded, size: 16, color: Colors.amber),
                        label: const Text('Flutter 3.x'),
                        backgroundColor: theme.colorScheme.primaryContainer.withValues(alpha: 0.4),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Grid of Activities
                  GridView.count(
                    crossAxisCount: isWideScreen ? 3 : (constraints.maxWidth > 500 ? 2 : 1),
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    shrinkWrap: true,
                    childAspectRatio: isWideScreen ? 1.4 : (constraints.maxWidth > 500 ? 1.25 : 1.1),
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      // Activity 1: Counter & Interactive Hub
                      ActivityCard(
                        title: 'Lab 1: Counter & Math Hub',
                        description: 'StatefulWidget demonstrating local count state, math logic, and history tracking.',
                        tag: 'Stateful Local',
                        icon: Icons.add_circle_outline_rounded,
                        accentColor: Colors.deepPurple,
                        isCompleted: appState.isActivityCompleted('lab1'),
                        onTap: () => Navigator.pushNamed(context, '/activity1'),
                        onToggleComplete: () => appState.toggleActivityCompletion('lab1'),
                      ),

                      // Activity 2: Task & Notes Planner
                      ActivityCard(
                        title: 'Lab 2: Task & Notes Planner',
                        description: 'Local item CRUD, category filters, and dynamic layout list updates.',
                        tag: 'Interactive CRUD',
                        icon: Icons.task_alt_rounded,
                        accentColor: Colors.teal,
                        isCompleted: appState.isActivityCompleted('lab2'),
                        onTap: () => Navigator.pushNamed(context, '/activity2'),
                        onToggleComplete: () => appState.toggleActivityCompletion('lab2'),
                      ),

                      // Activity 3: Design & Color Playground
                      ActivityCard(
                        title: 'Lab 3: Color & UI Playground',
                        description: 'Custom UI parameter controls, opacity sliders, and declarative color styling.',
                        tag: 'Declarative UI',
                        icon: Icons.palette_outlined,
                        accentColor: Colors.orange,
                        isCompleted: appState.isActivityCompleted('lab3'),
                        onTap: () => Navigator.pushNamed(context, '/activity3'),
                        onToggleComplete: () => appState.toggleActivityCompletion('lab3'),
                      ),

                      // Dedicated Settings Card
                      ActivityCard(
                        title: 'App Settings & Global State',
                        description: 'Configure student profile name, theme mode, and manage global Provider values.',
                        tag: 'Global Provider',
                        icon: Icons.tune_rounded,
                        accentColor: Colors.blueAccent,
                        isCompleted: false,
                        onTap: () => Navigator.pushNamed(context, '/settings'),
                        onToggleComplete: () => Navigator.pushNamed(context, '/settings'),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
