import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:kent_paulene_portfolio/main.dart';
import 'package:kent_paulene_portfolio/providers/app_state_provider.dart';

void main() {
  testWidgets('App loads home dashboard smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(
      ChangeNotifierProvider(
        create: (_) => AppStateProvider(),
        child: const MasterPortfolioApp(),
      ),
    );

    // Verify home dashboard title is rendered
    expect(find.text('Master Portfolio Hub'), findsOneWidget);
  });
}
