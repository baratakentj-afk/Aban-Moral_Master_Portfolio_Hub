import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'providers/app_state_provider.dart';
import 'screens/home_dashboard_screen.dart';
import 'screens/activity1_screen.dart';
import 'screens/activity2_screen.dart';
import 'screens/activity3_screen.dart';
import 'screens/settings_screen.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => AppStateProvider(),
      child: const MasterPortfolioApp(),
    ),
  );
}

class MasterPortfolioApp extends StatelessWidget {
  const MasterPortfolioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppStateProvider>(
      builder: (context, appState, child) {
        return MaterialApp(
          title: 'Kent & Paulene - Master Portfolio App',
          debugShowCheckedModeBanner: false,
          
          // Dynamic Global Theme Management
          themeMode: appState.themeMode,
          
          // Modern Material 3 Light Theme
          theme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(
              seedColor: Colors.deepPurple,
              brightness: Brightness.light,
            ),
            textTheme: GoogleFonts.interTextTheme(ThemeData.light().textTheme),
            appBarTheme: AppBarTheme(
              elevation: 0,
              scrolledUnderElevation: 2,
              centerTitle: false,
              titleTextStyle: GoogleFonts.outfit(
                color: Colors.black87,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          // Modern Material 3 Dark Theme
          darkTheme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(
              seedColor: Colors.deepPurple,
              brightness: Brightness.dark,
            ),
            textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme),
            appBarTheme: AppBarTheme(
              elevation: 0,
              scrolledUnderElevation: 2,
              centerTitle: false,
              titleTextStyle: GoogleFonts.outfit(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          // Navigation Routes Mapping
          initialRoute: '/',
          routes: {
            '/': (context) => const HomeDashboardScreen(),
            '/activity1': (context) => const Activity1Screen(),
            '/activity2': (context) => const Activity2Screen(),
            '/activity3': (context) => const Activity3Screen(),
            '/settings': (context) => const SettingsScreen(),
          },
        );
      },
    );
  }
}
